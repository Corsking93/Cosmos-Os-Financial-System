# COSMOS Finance OS

Autonomous financial operating system.

## Modules
- API Gateway
- Intent Engine
- Policy Brain
- Execution Swarm
- Settlement Layer (Bitcoin RPC-ready)
- Ledger Core (Postgres)
- Learning Loop

## Quick Start
```bash
npm install
docker-compose up --build
```
