const express = require("express");
const app = express();

app.use(express.json());

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.post("/payout", async (req, res) => {
  const { wallet, amount } = req.body;

  if (!wallet || !amount) {
    return res.status(400).json({ error: "missing fields" });
  }

  // emit signal (mock)
  console.log("SIGNAL:", { wallet, amount });

  res.json({
    status: "queued",
    wallet,
    amount
  });
});

app.listen(8000, () => {
  console.log("COSMOS API running on 8000");
});
