CREATE TABLE IF NOT EXISTS payouts (
  id SERIAL PRIMARY KEY,
  wallet TEXT,
  amount DECIMAL,
  txid TEXT,
  status TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
