function evaluate(intent) {
  if (intent.amount > 10) {
    return { action: "DELAY", confidence: 0.9 };
  }
  return { action: "APPROVE", confidence: 0.95 };
}

module.exports = { evaluate };
